import React from 'react';

const Layout: React.FC = ({ children }) => <div style={{minHeight:'100vh'}}>{children}</div>;

export default Layout;
