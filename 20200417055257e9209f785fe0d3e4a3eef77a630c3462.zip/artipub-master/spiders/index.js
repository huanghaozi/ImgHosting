module.exports = {
  JuejinSpider: require('./juejin'),
  SegmentfaultSpider: require('./segmentfault'),
  JianshuSpider: require('./jianshu'),
  CsdnSpider: require('./csdn'),
  ZhihuSpider: require('./zhihu'),
  OschinaSpider: require('./oschina'),
  ToutiaoSpider: require('./toutiao'),
  CnblogsSpider: require('./cnblogs'),
  V2exSpider: require('./v2ex'),
  WechatSpider: require('./wechat'),
}
