const BaseImportSpider = require('./base')

class JianshuImportSpider extends BaseImportSpider {
    async fetchArticles() {
    }
}

module.exports = JianshuImportSpider
