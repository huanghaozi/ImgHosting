const BaseImportSpider = require('./base')

class SegmentfaultImportSpider extends BaseImportSpider {
    async fetchArticles() {
    }
}

module.exports = SegmentfaultImportSpider
