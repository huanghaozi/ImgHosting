const BaseImportSpider = require('./base')

class CsdnImportSpider extends BaseImportSpider {
    async fetchArticles() {
    }
}

module.exports = CsdnImportSpider
