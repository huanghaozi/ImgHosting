module.exports = {
  article: require('./article'),
  task: require('./task'),
  platform: require('./platform'),
  cookie: require('./cookie'),
  environment: require('./environment'),
}
