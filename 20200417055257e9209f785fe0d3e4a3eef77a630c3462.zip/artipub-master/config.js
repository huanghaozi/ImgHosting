module.exports = {
  HOST: '0.0.0.0',
  PORT: 3000,
  MONGO_HOST: 'localhost',
  MONGO_PORT: '27017',
  MONGO_DB: 'artipub',
  MONGO_USERNAME: '',
  MONGO_PASSWORD: '',
  MONGO_AUTH_DB: 'admin'
}
